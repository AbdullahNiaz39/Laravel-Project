-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2020 at 05:50 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vegatable`
--

-- --------------------------------------------------------

--
-- Table structure for table `abouts`
--

CREATE TABLE `abouts` (
  `id` int(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(60) NOT NULL,
  `phonenumber` int(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `abouts`
--

INSERT INTO `abouts` (`id`, `name`, `email`, `password`, `phonenumber`, `created_at`, `updated_at`) VALUES
(8, 'rooney', 'rooney@gmail.com', 'fgdfgd34', 23425, '2020-03-29 21:17:25', '2020-03-29 21:17:25'),
(15, 'king', 'king@gmail.com', 'afsgdsg', 523434, '2020-03-30 20:02:05', '2020-08-16 13:42:31'),
(16, 'marcoRonney', 'marcoRonney@gamil.com', 'efreger45452', 214748364, '2020-03-30 20:02:37', '2020-08-23 13:15:25'),
(24, 'abdullah', 'email@gmail.com', '23432df', 43434234, '2020-04-03 12:37:24', '2020-04-03 12:37:24'),
(25, 'Noman king', 'email@gmail.com', '235463', 6565654, '2020-04-08 22:20:26', '2020-08-06 07:08:54'),
(27, 'hamza', 'abdullah.prince88@yahoo.com', 'rtert', 5556, '2020-04-08 22:25:19', '2020-08-06 07:10:26'),
(28, 'sherkhan', 'sher@gmail.com', 'sfgfh', 44443463, '2020-04-08 22:31:54', '2020-08-16 14:07:27'),
(29, 'ggfdfh', 'abdullah.prince88@yahoo.com', '4535346', 3435466, '2020-04-08 22:33:03', '2020-04-08 22:33:03'),
(30, 'fgdfg', 'abdullah.prince88@yahoo.com', 'trt', 3245, '2020-04-08 22:35:27', '2020-04-08 22:35:27'),
(31, 'fgdfg', 'abdullah.prince88@yahoo.com', 'fgdfgdh', 3245, '2020-04-08 22:36:33', '2020-04-08 22:36:33'),
(32, 'fgdfg', 'abdullah.prince88@yahoo.com', '574768', 3245, '2020-04-08 22:36:58', '2020-04-08 22:36:58'),
(33, 'sfdgsg', 'abdullah.prince88@yahoo.com', 'dghdgh', 3245, '2020-04-08 22:43:11', '2020-04-08 22:43:11'),
(35, 'sssss', 'fhgdfh@gmail', '2524', 3453466, '2020-04-08 22:48:34', '2020-04-08 22:48:34'),
(36, 'sgsfg', 'fhgdfh@gmail', '434636', 3453466, '2020-04-08 22:49:03', '2020-04-08 22:49:03'),
(38, 'EROZGAAR', 'sdfgsg@gmail.com', 'rgreger', 3636, '2020-04-08 22:59:08', '2020-04-08 22:59:08'),
(39, 'noman Akram', 'sdfgsg@gmail.com', '2656', 3636, '2020-04-08 23:00:56', '2020-04-08 23:00:56'),
(41, 'noman  class', 'kign@yahoo.com', 'dsfsdgg', 343535, '2020-04-10 18:28:37', '2020-04-10 18:28:37'),
(42, 'kk', 'abdullah.prince88@yahoo.com', 'sdgsdgsdg', 32523535, '2020-04-11 13:02:27', '2020-04-11 13:02:27'),
(43, 'fsgsdg', 'sdgsdg@gmail.com', '34235', 5252535, '2020-04-11 13:26:22', '2020-04-11 13:26:22'),
(44, 'Resus', 'goodPlayer@gmail.com', 'wqeqwe', 1231244, '2020-04-11 14:17:00', '2020-04-11 14:17:00'),
(45, 'soli', 'khan@gmail.com', 'rewrwr', 44324234, '2020-04-11 16:16:50', '2020-04-11 16:16:50'),
(46, 'kingg', 'ggg@gmail.com', 'rwerwer', 3244234, '2020-04-11 16:20:16', '2020-04-11 16:20:16'),
(47, 'ddd', 'fsgsfwrgtrtrtry@gmail.com', 'ewrwrewr', 234234234, '2020-04-11 16:33:25', '2020-04-11 16:33:25'),
(48, 'ali', 'jsss@gmail.com', 'dfsdf', 255235, '2020-04-11 16:55:00', '2020-04-11 16:55:00'),
(49, 'kkkkk', 'dfhdhfhd@gmail.com', 'sdfsdgsdg', 234243234, '2020-04-11 16:58:26', '2020-04-11 16:58:26'),
(50, 'ppppp', 'fsgsfwrgtrtrtry@gmail.com', 'erwerwerwer', 23434324, '2020-04-11 16:59:14', '2020-04-11 16:59:14'),
(51, 'kkk', 'fdgfsgsfgdsfsgsg@gmail.com', 'dfsdfsdgsg', 324234235, '2020-04-11 17:05:46', '2020-04-11 17:05:46'),
(52, 'dfdf', 'fsgsfwrgtrtrtry@gmail.come', 'rwerwer', 24234, '2020-04-11 17:08:36', '2020-04-11 17:08:36'),
(53, 'tttt', 'dsgs@gmail.com', 'dafsf', 34432432, '2020-04-11 17:09:12', '2020-04-11 17:09:12'),
(54, 'kkkk', 'abdullah.prince88@yahoo.com', 'fdssfdsd', 4543534, '2020-04-12 09:06:11', '2020-04-12 09:06:11'),
(55, 'dfdffdfd', 'email@gmail.com', 'dfdf', 34343443, '2020-04-13 00:09:37', '2020-04-13 00:09:37'),
(56, 'aaaaa', 'abdullah.prince88@yahoo.com', 'dffgf434', 435334, '2020-04-13 00:11:53', '2020-04-13 00:11:53'),
(57, 'aaaaa', 'abdullah.prince88@yahoo.com', 'dfdfdfdf', 435334, '2020-04-13 00:13:08', '2020-04-13 00:13:08'),
(58, 'aaaaa', 'abdullah.prince88@yahoo.com', '342525', 435334, '2020-04-13 00:13:39', '2020-04-13 00:13:39'),
(59, 'sdfsg', 'email@gmail.com', 'wwrrw33', 333333, '2020-04-13 00:14:53', '2020-04-13 00:14:53'),
(60, 'EROZGAAR', 'abdullah.prince88@yahoo.com', 'dfdf', 343435, '2020-04-13 00:16:11', '2020-04-13 00:16:11'),
(61, 'dfdfdf', 'abdullah.prince88@yahoo.com', 'dfdffd', 45454554, '2020-04-13 00:17:39', '2020-04-13 00:17:39'),
(62, 'EROZGAAR', 'dfdffd@gmail.com', 'dfdfdf', 34355, '2020-04-13 00:20:51', '2020-04-13 00:20:51'),
(64, 'ssssss', 'abdullah.prince88@yahoo.com', 'ssssss', 9798, '2020-04-13 08:28:16', '2020-04-13 08:28:16'),
(65, 'ssssss', 'abdullah.prince88@yahoo.com', 'sdsdsdsd', 9798, '2020-04-13 08:29:19', '2020-04-13 08:29:19'),
(66, 'noamn', 'abdullah.prince88@yahoo.com', 'dfdffd', 3455, '2020-04-13 08:33:37', '2020-04-13 08:33:37'),
(67, 'Salam', 'salam@gmail.com', '3333', 33333, '2020-04-13 13:41:12', '2020-04-13 13:41:12'),
(68, 'sss', 'abdullah.prince88@yahoo.com', 'fdfdfd', 3443443, '2020-04-13 06:51:30', '2020-04-13 06:51:30'),
(69, 'noman', 'email@gmail.com', 'ssff', 43434, '2020-04-13 06:52:04', '2020-04-13 06:52:04'),
(70, 'Abdullah', 'Abdullahniaz333@gamil.com', 'sss', 3435, '2020-04-13 14:00:56', '2020-04-13 14:00:56'),
(71, 'Abdullah', 'Abdullahniaz333@gamil.com', 'sdsd', 3435, '2020-04-13 14:03:02', '2020-04-13 14:03:02'),
(72, 'Abdullah', 'Abdullahniaz333@gamil.com', 'sdsdsd', 3435, '2020-04-13 14:03:17', '2020-04-13 14:03:17'),
(73, 'Abdullah', 'Abdullahniaz333@gamil.com', 'sdds', 3435, '2020-04-13 14:04:20', '2020-04-13 14:04:20'),
(74, 'noman', 'abdullah.prince88@yahoo.com', 'sss', 343535, '2020-04-13 18:08:45', '2020-04-13 18:08:45'),
(75, 'EROZGAAR', 'abdullah.prince88@yahoo.com', 'sdfgsdgsdg', 3424234, '2020-04-13 18:28:26', '2020-04-13 18:28:26'),
(76, 'Abdullah', 'abdullah.prince88@yahoo.com', 'dfsfsdf', 2343, '2020-04-13 22:31:43', '2020-04-13 22:31:43'),
(77, 'abdullah', 'abdullah.prince88@yahoo.com', 'dfdfdf', 88888, '2020-04-13 23:25:57', '2020-04-13 23:25:57'),
(78, 'abdullah', 'abdullah.prince88@yahoo.com', 'sss', 34355, '2020-04-14 00:31:00', '2020-04-14 00:31:00'),
(79, 'abdullah', 'abdullah.prince88@yahoo.com', 'yghjg', 6887, '2020-04-14 00:50:36', '2020-04-14 00:50:36'),
(80, 'ahmeeed', 'email@gmail.com', 'sssskkkk', 30423, '2020-08-06 05:07:16', '2020-08-23 13:15:50'),
(82, 'orange', 'marcokk@gamil.com', '2fffff', 3409999, '2020-08-23 06:20:48', '2020-08-23 06:20:48'),
(83, 'salman', 'salamn@gamil.com', 'longerman88', 3056666, '2020-08-23 13:22:53', '2020-08-23 13:22:53'),
(84, 'Abdullah', 'email@gmail.com', 'ssssss', 34080881, '2020-08-24 06:44:27', '2020-08-24 06:44:27'),
(85, 'kraman', 'kraman@gmail.com', 'malik', 22222, '2020-08-24 13:46:44', '2020-08-24 13:46:44');

-- --------------------------------------------------------

--
-- Table structure for table `cards`
--

CREATE TABLE `cards` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` double NOT NULL,
  `image` varchar(100) NOT NULL,
  `description` varchar(80) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cards`
--

INSERT INTO `cards` (`id`, `name`, `price`, `image`, `description`, `created_at`, `updated_at`) VALUES
(1, 'cabbages', 30, 'style/cabbages.jpg', 'fresh', '2020-04-13 07:41:02', '2020-04-13 07:41:02'),
(2, 'Radishes', 20, 'style/radishes2.jpg', 'Fresh', '2020-04-13 08:04:01', '2020-04-13 08:04:01'),
(3, 'Shallots', 80, 'style/Shallots.jpg', 'not Fresh', '2020-04-13 08:06:22', '2020-04-13 08:06:22'),
(4, 'Tomatoes', 120, 'style/tomatoes.jpg', 'Fresh', '2020-04-13 08:06:22', '2020-04-13 08:06:22'),
(5, 'chokos', 60, 'style/chokos.jpg', 'fresh', '2020-04-13 07:54:55', '2020-04-13 07:54:55'),
(6, 'Pumpkins', 60, 'style/pumpkins.jpg', 'Fresh', '2020-04-13 08:01:01', '2020-04-13 08:01:01'),
(7, 'onions', 55, 'style/onions.jpg', 'Fresh', '2020-04-13 07:56:41', '2020-04-13 07:56:41'),
(8, 'potatoes', 30, 'style/potatoes.jpg', 'fresh', '2020-04-13 07:59:41', '2020-04-13 07:59:41'),
(15, 'Asiangreens', 50, 'style/asiangreens.jpg', 'ssdds', '2020-04-13 14:45:03', '2020-04-13 14:45:03'),
(16, 'Courgettes', 40, 'upload/200413075229.jpg', 'Fresh', '2020-04-13 14:52:29', '2020-04-13 14:52:29'),
(17, 'swedes', 80, 'style/swedes.jpg', 'Fresh', '2020-04-13 08:09:54', '2020-04-13 08:09:54'),
(18, 'silverbeet', 39, 'upload/200413081207.jpg', 'Fresh', '2020-04-13 15:12:07', '2020-04-13 15:12:07'),
(19, 'beetroot', 50, 'upload/200413081411.jpg', 'Fresh', '2020-04-13 15:14:11', '2020-04-13 15:14:11'),
(20, 'bagan', 20, 'upload/200413081535.jpg', 'Fresh', '2020-04-13 15:15:35', '2020-04-13 15:15:35'),
(21, 'Chokos', 333, 'upload/200413113714.jpg', 'Fresh', '2020-04-13 18:37:14', '2020-04-13 18:37:14'),
(22, 'AsainGreens', 90, 'upload/200413153637.jpg', 'Fresh', '2020-04-13 22:36:37', '2020-04-13 22:36:37'),
(23, 'Apples', 250, 'upload/200413153714.jpg', 'Fresh', '2020-04-13 22:37:14', '2020-04-13 22:37:14'),
(24, 'tomatoes', 3333, 'upload/200413175302.jpg', 'Fresh', '2020-04-14 00:53:02', '2020-04-14 00:53:02'),
(25, 'kkk', 300, 'upload/200805232036.jpg', 'Fresh', '2020-08-06 06:21:01', '2020-08-06 06:21:01'),
(26, 'orange', 33, 'upload/200816000659.jpg', 'fresh', '2020-08-16 07:07:00', '2020-08-16 07:07:00'),
(27, 'Orange', 33, 'upload/200823061722.jpg', 'fresh', '2020-08-23 13:17:23', '2020-08-23 13:17:23'),
(28, 'Orange', 100, 'upload/200824064523.jpg', 'fresh', '2020-08-24 13:45:23', '2020-08-24 13:45:23'),
(29, 'orange', 454554, 'upload/200824071804.jpg', 'Fresh', '2020-08-24 14:18:04', '2020-08-24 14:18:04');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `informs`
--

CREATE TABLE `informs` (
  `id` int(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(44) NOT NULL,
  `message` varchar(500) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `informs`
--

INSERT INTO `informs` (`id`, `name`, `email`, `message`, `created_at`, `updated_at`) VALUES
(5, 'Sir imran Javed', 'imran javed33@gmail.com', 'He is great teacher and a great knowlegde about games and graphics', '2020-04-12 23:42:36', '2020-04-12 23:42:36'),
(9, 'abdullah', 'abdullah.prince88@yahoo.com', 'sssssssss', '2020-04-13 08:25:19', '2020-04-13 08:25:19'),
(12, 'abullah niaz', 'abdullah.prince88@yahoo.com', 'good boy', '2020-04-13 13:42:21', '2020-04-13 13:42:21'),
(14, 'abdullah', 'abdullah.prince88@yahoo.com', 'sfdfdffd', '2020-04-13 18:28:00', '2020-04-13 18:28:00'),
(15, 'EROZGAAR', 'abdullah.prince88@yahoo.com', 'your are good', '2020-04-13 22:33:33', '2020-04-13 22:33:33'),
(16, 'abdullah', 'abdullah.prince88@yahoo.com', 'your are good boy', '2020-04-14 00:33:04', '2020-04-14 00:33:04'),
(17, 'EROZGAAR', 'abdullah.prince88@yahoo.com', 'your website is ggoood', '2020-04-14 00:51:24', '2020-04-14 00:51:24'),
(18, 'Abdullah', 'abdullah.prince88@yahoo.com', 'sdfddfdf', '2020-08-06 05:08:15', '2020-08-06 05:08:15'),
(19, 'EROZGAAR', 'email@gmail.com', 'dsgsfhsfh', '2020-08-06 05:16:16', '2020-08-06 05:16:16'),
(20, 'ahmmdf', 'marcokk@gamil.com', 'dsgsgsg', '2020-08-16 07:38:36', '2020-08-16 07:38:36'),
(21, 'KING88', 'ahmed888@gmail.com', 'hello i wanna make website', '2020-08-23 13:24:07', '2020-08-23 13:24:07'),
(22, 'imran', 'ahmed777@gmail.com', 'you good teacher', '2020-08-24 13:46:19', '2020-08-24 13:46:19');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(70) NOT NULL,
  `image` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(50) NOT NULL,
  `description` varchar(70) NOT NULL,
  `price` float NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `seller_id` int(100) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `image`, `name`, `type`, `description`, `price`, `created_at`, `updated_at`, `seller_id`) VALUES
(1, '', 'prod1', '', 'prod1 laptop', 340000, '2020-04-01 18:12:25', '2020-04-01 18:12:25', 1),
(2, 'reus1.jpg', 'prod1', '', 'prod2 mobile', 120000, '2020-04-01 18:25:38', '2020-04-01 18:25:38', 4),
(3, '', 'rod3', '', 'tablets', 20000, '2020-04-01 18:25:38', '2020-04-01 18:25:38', 1),
(4, 'foo.jpg', 'dssdgdsg', 'laptop', 'egdfh', 454554, '2020-04-03 20:45:50', '2020-04-03 20:45:50', 1),
(5, '', 'fgdfgdfg', 'mobile', '234234', 23425200, '2020-04-03 20:46:45', '2020-04-03 20:46:45', 1),
(6, '', 'sdfsdg', 'laptop', 'sdgg', 32553, '2020-04-03 20:51:28', '2020-04-03 20:51:28', 1),
(7, '', 'sdfsdg', 'laptop', 'sdgg', 32553, '2020-04-03 20:56:16', '2020-04-03 20:56:16', 1),
(8, 'foo.jpg', 'iphone', 'tablet', 'e4', 500000, '2020-04-04 22:34:19', '2020-04-04 22:34:19', 5),
(9, 'upload/200404155353.jpg', 'laptop', 'laptop', 'sdgg', 300000, '2020-04-04 22:53:53', '2020-04-04 22:53:53', 1),
(10, 'upload/200404161918.jpg', 'hp', 'laptop', 'e3', 100001, '2020-04-04 23:19:18', '2020-04-04 23:19:18', 1),
(11, 'upload/200410142517.jpg', 'sdf', 'laptop', 'sdgdsg', 5436360, '2020-04-10 21:25:17', '2020-04-10 21:25:17', 1),
(12, 'upload/200512060856.jpg', 'caed id', 'mobile', 'good', 3434, '2020-05-12 13:08:57', '2020-05-12 13:08:57', 1),
(13, 'upload/200512063407.jpg', 'noman', 'tablet', 'best', 30000, '2020-05-12 13:34:07', '2020-05-12 13:34:07', 1),
(14, 'upload/200516063459.jpg', 'abdullah', 'mobile', 'Fresh', 3434, '2020-05-16 13:35:00', '2020-05-16 13:35:00', 1),
(15, 'upload/200516063710.jpg', 'dsfgs', 'mobile', 'sdgg', 300, '2020-05-16 13:37:10', '2020-05-16 13:37:10', 1),
(16, 'upload/200516070424.jpg', 'EROZGAAR', 'tablet', 'dfdf', 2323, '2020-05-16 14:04:24', '2020-05-16 14:04:24', 1),
(17, 'upload/200516071832.jpg', 'hp', 'laptop', '4th', 340000, '2020-05-16 14:18:32', '2020-05-16 14:18:32', 1),
(18, 'upload/200516072043.jpg', 'samsung', 'mobile', 'a8', 34340, '2020-05-16 14:20:43', '2020-05-16 14:20:43', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_tag`
--

CREATE TABLE `product_tag` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_tag`
--

INSERT INTO `product_tag` (`id`, `product_id`, `tag_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2020-04-10 16:49:36', '2020-04-10 16:49:36'),
(2, 1, 2, '2020-04-10 16:49:36', '2020-04-10 16:49:36'),
(3, 2, 1, '2020-04-10 16:50:38', '2020-04-10 16:50:38'),
(4, 3, 2, '2020-04-10 16:50:38', '2020-04-10 16:50:38'),
(5, 7, 3, '2020-05-12 07:18:39', '2020-05-12 07:18:39'),
(6, 17, 1, '2020-05-16 07:18:32', '2020-05-16 07:18:32'),
(7, 17, 2, '2020-05-16 07:18:32', '2020-05-16 07:18:32'),
(8, 17, 3, '2020-05-16 07:18:32', '2020-05-16 07:18:32'),
(9, 18, 1, '2020-05-16 07:20:43', '2020-05-16 07:20:43'),
(10, 18, 3, '2020-05-16 07:20:43', '2020-05-16 07:20:43');

-- --------------------------------------------------------

--
-- Table structure for table `sellers`
--

CREATE TABLE `sellers` (
  `id` int(100) NOT NULL,
  `name` varchar(80) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sellers`
--

INSERT INTO `sellers` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Ali', '2020-04-02 05:23:18', '2020-04-02 05:23:18'),
(4, 'Noman', '2020-04-02 05:23:18', '2020-04-02 05:23:18'),
(5, 'Umar', '2020-04-10 14:55:22', '2020-04-10 14:55:22');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Electronics', '2020-04-10 16:46:14', '2020-04-10 16:46:14'),
(2, 'computer', '2020-04-10 16:50:16', '2020-04-10 16:50:16'),
(3, 'devices', '2020-04-10 16:50:16', '2020-04-10 16:50:16');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(4, 'Administer', 'admin888@gmail.com', '2020-08-13 07:00:00', '$2y$10$apMWgCz/Tus0aGvQI6/1KO5qjzFF32kKMZthvWvEhVnRFzaQVDHe6', NULL, '2020-07-24 13:51:46', '2020-07-24 13:51:46'),
(5, 'Admin', 'Adminuser@gmail.com', '2020-09-05 07:00:00', '$2y$10$3PUBUDCGyIPVir3uT7H0BOGzM7KNNtXHpdpO7jBFuHI2kTrQXNDiq', NULL, '2020-08-16 12:44:36', '2020-08-16 12:44:36'),
(6, 'Abdullah Niaz', 'Abdullahniaz@gmail.com', NULL, '$2y$10$8ry9IKDqX2i3Grb7bO/28eMM.TtskyT9KyWNG/kqdOAA.S0PnZjJK', NULL, '2020-08-23 13:27:31', '2020-08-23 13:27:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abouts`
--
ALTER TABLE `abouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cards`
--
ALTER TABLE `cards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `informs`
--
ALTER TABLE `informs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `seller_id` (`seller_id`);

--
-- Indexes for table `product_tag`
--
ALTER TABLE `product_tag`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sellers`
--
ALTER TABLE `sellers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abouts`
--
ALTER TABLE `abouts`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `cards`
--
ALTER TABLE `cards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `informs`
--
ALTER TABLE `informs`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(70) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `product_tag`
--
ALTER TABLE `product_tag`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `sellers`
--
ALTER TABLE `sellers`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `sellers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
